import 'package:bangladesh_map/bdmap.dart';
import 'package:bangladesh_map/indian_map.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      systemNavigationBarColor: Colors.green,
      statusBarColor: Colors.green,
    ));
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Bangladesh Map',
      theme: ThemeData(
        primaryColor: Colors.green,
        primarySwatch: Colors.blue,
      ),
      home: BangladeshMap(),
    );
  }
}
